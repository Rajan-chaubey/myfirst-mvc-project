//make the required changes to this class so that InvalidPackageIdException is of type exception.
public class InvalidPackageIdException extends Exception{

//fill your code here
	
	
	public InvalidPackageIdException(){
		
	}

	public InvalidPackageIdException(String message) {
		super(message);
	}

	
}
	
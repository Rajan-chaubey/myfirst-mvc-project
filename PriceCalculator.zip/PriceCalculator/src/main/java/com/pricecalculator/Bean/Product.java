package com.pricecalculator.Bean;

import javax.validation.Validation;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;

public class Product {
	@NotNull(message ="{price.not.empty}")
	@Min(value = 1,message="{price.min.value}")
	private double productPrice;
	private String productType;
	public double getProductPrice() {
		return productPrice;
	}
	public void setProductPrice(double productPrice) {
		this.productPrice = productPrice;
	}
	public String getProductType() {
		return productType;
	}
	public void setProductType(String productType) {
		this.productType = productType;
	}
	
}

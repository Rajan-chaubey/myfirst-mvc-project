package com.pricecalculator.Controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Controller;
import org.springframework.stereotype.Service;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.validation.Validator;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.pricecalculator.Bean.Product;
import com.pricecalculator.Service.DiscountServiceInterface;

@Controller
class DiscountController {
	
	@Autowired
	private DiscountServiceInterface discountService;
	
	@Autowired
	private Validator validator;
	
	@RequestMapping(value = "/getDiscountedPrice",method=RequestMethod.GET)
	public String discountPage(@ModelAttribute("product") Product productBean) {
		productBean=new Product();
		return "calculatediscount";
	}
	
	@RequestMapping(value = "/calculateDiscountedPrice",method=RequestMethod.GET)
	public String calculateDiscount(@ModelAttribute("product") Product productBean,ModelMap map,BindingResult result) {
		validator.validate(productBean, result);
		if(result.hasErrors()) {
			return "calculatediscount";
		}else {
			double discountedAmount=discountService.calculateDiscount(productBean);
			map.addAttribute("discountedAmount", discountedAmount);
			return "finalprice";
		}
		
	}
	
	@ModelAttribute("productTypeList")
	public List<String> populateProductType(){
		List<String> productTypeList=new ArrayList<String>();
		productTypeList.add("Electronic");
		productTypeList.add("Apparels");
		productTypeList.add("Toys");
		return productTypeList;
	}
}

package com.pricecalculator.Service;

import com.pricecalculator.Bean.Product;

public interface DiscountServiceInterface {
	double calculateDiscount(Product product);
}

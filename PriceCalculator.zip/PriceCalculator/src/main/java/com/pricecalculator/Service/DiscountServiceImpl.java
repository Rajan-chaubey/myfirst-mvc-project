package com.pricecalculator.Service;

import org.springframework.stereotype.Service;

import com.pricecalculator.Bean.Product;


@Service
public class DiscountServiceImpl implements DiscountServiceInterface{
	public double calculateDiscount(Product product) {
		// TODO Auto-generated method stub
		//Discounted Price = Product Price - ( Product Price *(Discount percentage /100))
		double discountPrice=0;
		if(product.getProductType().equals("Electronic")) {
		discountPrice=product.getProductPrice()-((product.getProductPrice())*25/100);
		}else  if(product.getProductType().equals("Apparels")) {
			discountPrice=product.getProductPrice()-((product.getProductPrice())*10/100);
		}else  if(product.getProductType().equals("Toys")) {
			discountPrice=product.getProductPrice()-((product.getProductPrice())*10/100);
		}else {
			discountPrice=0.0;
		}
		
		return discountPrice;
	}
}

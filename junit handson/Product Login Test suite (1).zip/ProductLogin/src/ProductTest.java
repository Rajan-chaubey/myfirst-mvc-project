import org.junit.Test;
import static org.junit.Assert.fail;



import static org.junit.Assert.*;

public class ProductTest {

 //Write the code for test methods

	
	Product	p = new Product();
	Product	p2=null;
	Product	p1 = new Product("12","asdfgh",123.01);
	ProductDAO	pd = new ProductDAO();

	
	@Test
	public void testDeleteProductWithConstructor(){
		pd.addProduct(p1);
		assertTrue(pd.deleteProduct(p1));
	}
	@Test
	public void testDeleteProduct(){
		pd.addProduct(p);
		assertTrue(pd.deleteProduct(p));
	}
	
	@Test
	public void testDeleteProduct1(){
		p.setPrice(566.363);
		p.setProductId("333");
		p.setProductName("ppk");
		pd.addProduct(p);
		assertTrue(pd.deleteProduct(p));
	}
	
	@Test
	public void testDeleteProductNull(){
		assertFalse(pd.deleteProduct(p2));
	}
	/*@Test
	public void testDeleteProductNotAvailable(){
		assertFalse(pd.deleteProduct(new Product(null,"sdfs",45.36)));
	}
	*/
	
	@Test
	public void testdeleteProductWithFail(){
		pd.addProduct(null);
		assertFalse(pd.deleteProduct(null));
	}
/*	@Test
	public void testAddProduct(){
		assertTrue(pd.addProduct(p));
	}*/
}

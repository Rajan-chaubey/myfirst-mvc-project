import org.junit.Test;
import static org.junit.Assert.*;


public class LoginTest {
		
	
     Login lo = new Login("asdf", "qwer");
     Login lo2 = new Login("abc", "abc");
     Login lo1 = new Login();
     Login login=null;
    LoginDAO l = new LoginDAO();
    
      //Write the code for adding and deleting Login data

    
    
    @Test
	public void testDeleteLogin1(){
    	l.addLogin(lo1);
    	
		assertTrue(l.deleteLogin(lo1));
	}
    
    
    @Test
	public void testDeleteLogin2(){
    
    	lo1.setUserName("pp");
    	lo1.setPassword("pp");
    	l.addLogin(lo1);
		assertTrue(l.deleteLogin(lo1));
	}
    @Test
   	public void testDeleteLoginNull(){
    	l.addLogin(login);
   		assertFalse(l.deleteLogin(login));
   	}
    

    @Test
   	public void testDeleteLoginNotPresent(){
   		assertFalse(l.deleteLogin(new Login("aa", "aa")));
   	}
	@Test
	public void testDeleteLogin(){
		l.addLogin(lo);
		assertTrue(l.deleteLogin(lo));
	}
	/*@Test
	public void testDeleteLoginNullData(){
		l.addLogin(new Login(null,null));
		assertFalse(l.deleteLogin(new Login(null,null)));
	}*/
	

}


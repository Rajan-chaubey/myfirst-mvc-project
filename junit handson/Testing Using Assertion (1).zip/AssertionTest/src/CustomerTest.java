import static org.junit.Assert.*;

import org.junit.Test;

public class CustomerTest {
	Customer cust=null;

	@Test
	public void testIsValidAadharNo1() {
		cust = new Customer("789456789456","first","last","address",1234567890,"abc@gmail.com");
		assertTrue(cust.isValidAadharNo("789456789456"));
	}

	@Test
	public void testIsValidAadharNo2() {
		cust = new Customer("005456789456","first","last","address",1234567890,"abc@gmail.com");
		assertFalse(cust.isValidAadharNo("005456789456"));
	}

	@Test
	public void isFirstAndLastNameEqual() {

		cust = new Customer("789456789456","first","last","address",1234567890,"abc@gmail.com");
		assertNotEquals(cust.getFirstName(),cust.getLastName());
	}

	@Test
	public void isEmailIdNull() {
		cust = new Customer("789456789456","first","last","address",1234567890,"abc@gmail.com");
		assertNotNull(cust.getEmailId());
	}

}

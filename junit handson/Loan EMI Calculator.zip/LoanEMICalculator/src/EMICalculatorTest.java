import static org.junit.Assert.assertEquals;
import java.util.*;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameters;
@RunWith(Parameterized.class)
public class EMICalculatorTest {


//Write JUNIT Test Code


    private double p;
    private String lt;
    private double dy;
    private double exp;
    public EMICalculatorTest(double p,String lt,double dy,double exp){
       this.p=p;
       this.lt=lt;
       this.dy=dy;
       this.exp=exp;
    }
    @Parameters
    public static Collection data(){
       return Arrays.asList(new Object[][]{
           {100000.0,"Vehicle Loan",5.0,1671.3305889173132},
           {200000.0,"Housing Loan",5.0,3343.5099967167816},
           {100000.0,"Personal Loan",5.0,1670.9062488873578},
             {100000.0,"Personal Loan",25.0,0.0}
       });
    }


@Test
public void test1(){
    EMICalculator e= new EMICalculator();
    assertEquals(exp,e.calculateEMI(p,lt,dy),0.0);
}




    
}

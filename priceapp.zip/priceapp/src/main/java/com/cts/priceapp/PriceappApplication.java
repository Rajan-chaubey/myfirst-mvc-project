package com.cts.priceapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PriceappApplication {

	public static void main(String[] args) {
		SpringApplication.run(PriceappApplication.class, args);
	}

}

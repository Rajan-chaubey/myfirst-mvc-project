package com.cts.priceapp.service;

import com.cts.priceapp.model.Product;

public interface DiscountService {

	double calculateDiscount(Product product);
}

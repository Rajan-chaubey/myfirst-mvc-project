package com.example.todomanager;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TodomanagerApplicationTests {

	@Test
	void contextLoads() {
	}

}


public class InvalidCityPincodeException extends Exception {
	public InvalidCityPincodeException() {
		
	}

	public InvalidCityPincodeException(String message) {
		super(message);
	}
}

package com.pricecalculator.ControllerServicePojo;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class DiscountController {
	
	@Autowired
	private DiscountServiceInterface discountService;

	@RequestMapping(value = "/getDiscountedPrice" , method= RequestMethod.GET)
	public String discountPage(@ModelAttribute("product") Product product){
		return "calculatediscount";
	}
	
	
	@RequestMapping(value = "/calculateDiscountedPrice" , method= RequestMethod.GET)
	public String calculateDiscount(@ModelAttribute("product") @Valid Product product , ModelMap modelMap , BindingResult result){
		DiscountServiceInterface discountServiceInterface = new DiscountServiceInterface();
		double cost = discountServiceInterface.calculateDiscount(product);
		modelMap.addAttribute("totalCost", cost);
		if(result.hasErrors()){
			return "calculatediscount";
		}
		else{
			return "finalPrice";
		}
		
	}
	
	@ModelAttribute("productTypeList")
	public List<String> populateProductType(){
		List<String> productTypeList = new ArrayList<String>();
		productTypeList.add("Electronic");
		productTypeList.add("Apparels");
		productTypeList.add("Toys");
		return productTypeList;
		
	}
}

package com.pricecalculator.ControllerServicePojo;

import org.springframework.stereotype.Service;

@Service
public class DiscountServiceInterface {

	public double calculateDiscount(Product product){
		double costToBeCalculated = 0.0;
		if(product.getProductType().equals("Electronic")){
			costToBeCalculated = product.getProductPrice() - product.getProductPrice()*0.25;
		}
		else if(product.getProductType().equals("Apparels")){
			costToBeCalculated = product.getProductPrice() - product.getProductPrice()*0.10;
		}
		else{
			costToBeCalculated = product.getProductPrice() - product.getProductPrice()*0.50;
		}
		return costToBeCalculated;
	
	}
}

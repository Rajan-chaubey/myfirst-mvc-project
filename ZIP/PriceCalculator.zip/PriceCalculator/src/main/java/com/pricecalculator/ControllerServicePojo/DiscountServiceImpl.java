package com.pricecalculator.ControllerServicePojo;

public class DiscountServiceImpl {

}

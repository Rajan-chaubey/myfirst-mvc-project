package com.cognizant.truyum.dao;
import java.util.*;
import com.cognizant.truyum.model.*;

public interface CartDao {
	
		public void  addCartItem(long userId, long menuItemId);
		
		
		public void removeCartItem(long userId, long menuItemId);
		
		
		public List<MenuItem> getAllCartItems(long userId) throws CartEmptyException ;
		
}

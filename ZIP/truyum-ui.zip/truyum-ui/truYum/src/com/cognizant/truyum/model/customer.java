package com.cognizant.truyum.model;

public class customer {

}

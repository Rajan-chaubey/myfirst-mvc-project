package com.cognizant.truyum.dao;

import java.util.ArrayList;


import com.cognizant.truyum.model.MenuItem;


public class CartDaoCollectionImplTest  {

       public static void testAddCartItem() throws CartEmptyException
    {  CartDaoCollectionImpl cartDaoCollectionImpl = new  CartDaoCollectionImpl();
    CartDao cartDao= cartDaoCollectionImpl;
    cartDao.addCartItem(1, 0004);
    cartDao.addCartItem(1, 0002);
   ArrayList<MenuItem> menuItemList = (ArrayList<MenuItem>) cartDao.getAllCartItems(1);
   System.out.println("cart list after reading");
   for (MenuItem menuItem :menuItemList)
       {
              System.out.println(menuItem.toString());
       }
   System.out.println();
    }
    public static void testGetAllCartItems() throws CartEmptyException
    {
         CartDaoCollectionImpl cartDaoCollectionImpl = new  CartDaoCollectionImpl();
          CartDao cartDao= cartDaoCollectionImpl;
          ArrayList<MenuItem> menuItemList =  (ArrayList<MenuItem>)cartDao.getAllCartItems(1);
         System.out.println("cart list");
         for (MenuItem menuItem :menuItemList)
       {
             System.out.println(menuItem.toString());
       }
         System.out.println();
                  
    }
    public static void testRemoveCartItem() throws CartEmptyException
    {
       CartDaoCollectionImpl cartDaoCollectionImpl =new CartDaoCollectionImpl();
       CartDao cartDao = cartDaoCollectionImpl;
       cartDao.removeCartItem(1, 00004);
       ArrayList<MenuItem> menuItemList = (ArrayList<MenuItem>) cartDao.getAllCartItems(1);
       System.out.println("Cart List after removel of menuitem with id=4:");
       for (MenuItem menuItem :menuItemList)
       {
              System.out.println(menuItem.toString());
       }
                    System.out.println();
    }

    
       public static void main(String[] args) throws CartEmptyException
       {
          testAddCartItem();
          testGetAllCartItems();
          testRemoveCartItem();
        }
}


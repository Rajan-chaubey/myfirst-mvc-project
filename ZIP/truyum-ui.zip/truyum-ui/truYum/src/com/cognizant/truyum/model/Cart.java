package com.cognizant.truyum.model;

import java.util.ArrayList;

public class Cart {
	private double total;

	public Cart(int i, ArrayList<MenuItem> cartMenu) {
		// TODO Auto-generated constructor stub
	}

	public void setMenuItemList(ArrayList<MenuItem> removeList) {
		// TODO Auto-generated method stub
		
	}

	public ArrayList<MenuItem> getMenuItemList() {
		// TODO Auto-generated method stub
		return null;
	}

	public void setTotal(float value) {
		// TODO Auto-generated method stub
		
	}


}

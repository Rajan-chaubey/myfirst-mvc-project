INSERT INTO menu_item (me_id, me_name, me_price, me_active, me_date_of_launch, me_category, me_free_delivery)
VALUES ('1', 'Sandwich', 'Rs. 99.00', 'Yes', '15/03/2017', 'Main course' ,'yes');

INSERT INTO menu_item (me_id, me_name, me_price, me_active, me_date_of_launch, me_category, me_free_delivery)
VALUES ('2', 'Burger', 'Rs. 129.00', 'Yes', '23/12/2017', 'Main course' ,'no');

INSERT INTO menu_item (me_id, me_name, me_price, me_active, me_date_of_launch, me_category, me_free_delivery)
VALUES ('3', 'Pizza', 'Rs. 149.00', 'Yes', '21/08/2017', 'Main course' ,'no');

INSERT INTO menu_item (me_id, me_name, me_price, me_active, me_date_of_launch, me_category, me_free_delivery)
VALUES ('4', 'french fries', 'Rs. 57.00', 'No', '02/07/2017', 'starters' ,'yes');

INSERT INTO menu_item (me_id, me_name, me_price, me_active, me_date_of_launch, me_category, me_free_delivery)
VALUES ('5', 'choclate brownies', 'Rs. 32.00', 'Yes', '02/11/2022', 'desert' ,'yes');

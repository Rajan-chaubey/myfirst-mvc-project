package com.service;

import org.springframework.stereotype.Service;

import com.model.Ticket;;
@Service
public class TicketService {
	
	
	public double calculateTotalCost(Ticket ticket)
	{
		String type=ticket.getCircleType();
		int no=ticket.getNoOfTickets();
		double cost=0.0;
		if(type.equals("Queen"))
		{
			cost=no*250;
		}
		else if(type.equals("King"))
		{
			cost=no*150;
		}
		return cost;
		
	}

}
	 	  	    	    	     	      	 	


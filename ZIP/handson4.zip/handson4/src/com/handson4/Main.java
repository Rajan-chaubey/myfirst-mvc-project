package com.handson4;
import java.util.*;
import java.io.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import com.handson4.ConnectionHandler;
public class Main {
	
       static PreparedStatement statement;
       static ResultSet resultSet;
       
       public static void main(String[] args) throws Exception {
              
              
              File file = new File("D:\\dushyant\\handson4\\data");
              SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy");
              
              BufferedReader br = new BufferedReader(new FileReader(file));
              String st;
              String [] per;

              execute person;
              Date dob =null;
              boolean res = false;
              while ((st = br.readLine()) != null){
                     System.out.println(st);
                     res = false;
                     per = st.split(",");
                     String regx = "^[\\p{L} .'-]+$";
                     if(per[0].matches(regx)){
                           res = true;
                     }
                     else{
                           System.out.println("Incorrect Name");
                           continue;
                     }
                     if(per[2].charAt(0) == 'd' && per[2].charAt(1) == '-'){
                           res = true;
                     }
                     else{
                           System.out.println("Invalid Department");
                           continue;
                     }
                     try{
                     String s = per[5].trim();
                     dob = formatter.parse(s);
                     }
                     catch(ParseException ex)
                     {
                           res = false;
                           System.out.println("Wrong Date Format");
                           continue;
                                  
                           
                      }
                     
                      if(res){
                           
                           person = new execute();
                           person.setName(per[0]);
                           person.setRollno(Integer.parseInt(per[1]));
                           person.setDepartment(per[2]);
                           person.setResult(per[3]);
                           person.setPercentage(Float.parseFloat(per[4]));
                           person.setDob(dob);
                           addPerson(person);
                           
                            
                      }
                     
                      
               }
              showAll();
              getPerson(21);
            
                      
    }
       
       public static void showAll(){
              
              try(Connection connection = ConnectionHandler.getConnection()){
                          statement = connection.prepareStatement("select * from Person");
                           resultSet = statement.executeQuery();
                           execute item;
                           while(resultSet.next())
                           {
                                  item = new execute();
                                  
                                  item.setName(resultSet.getString(1));
                                  item.setRollno(resultSet.getInt(2));
                                  item.setDepartment(resultSet.getString(3));
                                  item.setResult(resultSet.getString(4));
                                  item.setPercentage(resultSet.getFloat(5));
                                  item.setDob(new Date(resultSet.getDate(6).getTime()));
                                  
                                  System.out.println(item);
                           }
                                  
              }
                           catch(Exception e){
                                  e.printStackTrace();
                           }
                     
              
       }
       
       public static void getPerson(int rollno){
              
              try(Connection connection = ConnectionHandler.getConnection()){
                     statement = connection.prepareStatement("select * from person where rollno = ?;");
                     statement.setInt(1,rollno);
                     resultSet = statement.executeQuery();
                     execute item;
                     while(resultSet.next())
                     {
                           item = new execute();
                           
                           item.setName(resultSet.getString(1));
                           item.setRollno(resultSet.getInt(2));
                           item.setDepartment(resultSet.getString(3));
                           item.setResult(resultSet.getString(4));
                           item.setPercentage(resultSet.getFloat(5));
                           item.setDob(new Date(resultSet.getDate(6).getTime()));
                           System.out.println("\n\n\n\n\n\n\n");
                           System.out.println(item);
                     }
                           
                     }
                           
                     
                     catch(Exception e){
                           e.printStackTrace();
                     }
              
              
       }
              
       
       
       public static void addPerson(execute p){
                     
                      try(Connection connection = ConnectionHandler.getConnection()){
                                  statement = connection.prepareStatement("insert into person values(?,?,?,?,?,?)");
                                  statement.setString(1,p.getName());
                                  statement.setInt(2,p.getRollno());
                                  statement.setString(3, p.getDepartment());
                                  statement.setString(4, p.getResult());
                                  statement.setFloat(5, p.getPercentage());
                                  statement.setDate(6, new java.sql.Date(p.getDob().getTime()));
                                  
                                  statement.executeUpdate();
                                  System.out.println("\n\n\n Person Details Added \n\n");    
                      }
                                  catch(Exception e){
                                         e.printStackTrace();
                                  }
                 
       
       }
       
    
}


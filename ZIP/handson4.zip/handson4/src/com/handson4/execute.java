package com.handson4;
import java.util.Date;

public class execute {

	private String name;
	private int rollno;
	private String department;
	private String result;
	private float percentage;
	private Date dob;
	
	public execute(String name, int rollno, String department, String result, float percentage, Date dob) {
		super();
		this.name = name;
		this.rollno = rollno;
		this.department = department;
		this.result = result;
		this.percentage = percentage;
		this.dob = dob;
	}

	public execute() {
		
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getRollno() {
		return rollno;
	}

	public void setRollno(int rollno) {
		this.rollno = rollno;
	}

	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

	public String getResult() {
		return result;
	}

	public void setResult(String result) {
		this.result = result;
	}

	public float getPercentage() {
		return percentage;
	}

	public void setPercentage(float percentage) {
		this.percentage = percentage;
	}

	public Date getDob() {
		return dob;
	}

	public void setDob(Date dob) {
		this.dob = dob;
	}
	
}

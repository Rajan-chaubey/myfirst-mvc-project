package com.handson4;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class ConnectionHandler {
	
	static Connection connection;

	public static Connection getConnection(){
		
		try(InputStream input = new FileInputStream("src/connection.properties");){
			
			Properties prop = new Properties();
			prop.load(input);
			Class.forName(prop.getProperty("driver"));
			connection = DriverManager.getConnection(
				prop.getProperty("url"),
				prop.getProperty("username"),
				prop.getProperty("password"));
			
			
		} catch (IOException | ClassNotFoundException | SQLException e) {
			
			e.printStackTrace();
		}
	return connection;
	}
	
	public static void main(String[] args) {
		System.out.println(ConnectionHandler.getConnection());
	}
}

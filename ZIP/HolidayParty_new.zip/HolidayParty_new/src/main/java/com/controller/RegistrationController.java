package com.controller;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.model.RegistrationBean;
import com.validate.CustomValidator;
@Controller
public class RegistrationController {
	@Autowired
	CustomValidator validator;
	@InitBinder
	public void initBinder(WebDataBinder binder) {
		binder.addValidators(validator);
		
	}
	
	@RequestMapping("/registerPage")
	public String showRegisterPage(Model model) {
		RegistrationBean registrationBean=new RegistrationBean();
		model.addAttribute("registrationBean",registrationBean);
		return "registrationpage";
	}
	

	 @RequestMapping(value="/register",method=RequestMethod.POST)
	  public String performRegistration(@Valid @ModelAttribute RegistrationBean  registrationBean, 
			BindingResult result,Model model) {
		 if(result.hasErrors()) {
			/* model.addAttribute("registraionBean",registrationBean); */
			
			 return "registrationpage";
		 }
		 	model.addAttribute("name",registrationBean.getUserName());
		 	model.addAttribute("email",registrationBean.getEmailId());
            	return "thankyou";
	
	
	}	 	  		    	    	     	      	 	
}

package com.validate;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.model.RegistrationBean;
@Component
public class CustomValidator implements Validator{

	
	public void validate(Object arg0, Errors arg1) {
		
		ValidationUtils.rejectIfEmpty(arg1, "userName", "rb.userName.empty","User Name Cannot be blank");
		ValidationUtils.rejectIfEmpty(arg1, "contactNumber", "rb.contactNumber.empty","Contact Number should not be blank");
		ValidationUtils.rejectIfEmpty(arg1, "emailId", "rb.emailId.empty","Email ID cannot be blank");
		ValidationUtils.rejectIfEmpty(arg1, "confirmEmailId", "rb.confirmEmailId.empty","Confirm Email ID cannot be blank");
		//ValidationUtils.rejectIfEmpty(arg1, "status", "rb.status.empty","pleae agree to the terms and conditions");
		
		
		RegistrationBean rg=(RegistrationBean) arg0;
		if(!String.valueOf(rg.getContactNumber()).matches("^\\d{10}")) {
			
			arg1.rejectValue("contactNumber", "rb.contact.invalid", "Contact Number should be of 10 digits");
			
		}
		
		if(rg.getEmailId().indexOf("@")==-1) {
			arg1.rejectValue("emailId", "rb.email.invalid", "Should be a proper email ID format");
		}
		
		if(rg.getConfirmEmailId().indexOf("@")==-1) {
			arg1.rejectValue("confirmEmailId", "rb.cemail.invalid", "Should be a proper email ID format");
		}
		
		if(!rg.getEmailId().equals(rg.getConfirmEmailId())) {
			arg1.rejectValue("confirmEmailId", "rb.emails.notmatching", "Email and Confirm Email should be same");
			
		}
		
		if(!rg.isStatus()) {
			arg1.rejectValue("status", "rb.status.empty","please agree to the terms and conditions"  );
			
		}
			
	}	 	  	    	    	     	      	 	

	public boolean supports(Class<?> arg0) {
		// TODO Auto-generated method stub
		return RegistrationBean.class.equals(arg0);
	}
	

}

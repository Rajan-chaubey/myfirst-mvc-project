import java.sql.Connection;
import java.sql.PreparedStatement;

public class FlightManagementSystem{
    public boolean addFlight(Flight flightObj){
    	
    	int id = flightObj.getFlightId();
    	String source = flightObj.getSource();
    	String des = flightObj.getDestination();
    	int nos = flightObj.getNoOfSeats();
    	double ff = flightObj.getFlightFare();
    	
    	String query = "Insert into flight values(?,?,?,?,?)";
    	
    	try{
    		Connection con = DB.getConnection();
			PreparedStatement stmt = con.prepareStatement(query);
    		stmt.setInt(1, id);
    		stmt.setString(2, source);
    		stmt.setString(3, des);
    		stmt.setInt(4, nos);
    		stmt.setDouble(5, ff);
    		int result=stmt.executeUpdate();
    		if(result == 1)
    			return true;
    		else
    			return false;
        	
    	}
    	catch(Exception e){
    		return false;
    	}
    	
    }
}
import java.util.*;

import com.sun.org.apache.xerces.internal.util.SynchronizedSymbolTable;
public class Main{
    public static void main(String[] args){
        Scanner sc=new Scanner(System.in);
        
        int id = sc.nextInt();
        sc.nextLine();
    	String source = sc.nextLine();
    	String des = sc.nextLine();
    	int nos = sc.nextInt();
    	double ff = sc.nextDouble();
    	
        Flight f = new Flight(id, source, des, nos, ff);
        FlightManagementSystem fm=new FlightManagementSystem();
        boolean result=fm.addFlight(f);
        if(result){
        	System.out.println("Flight details added successfully");
        }
        else{
        	System.out.println("Addition not done");
        }
        
        
    }
}
import java.util.Scanner;

public class Authority {
	public static void main(String args[]) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Inmate's name:");
		String name = sc.nextLine();
		System.out.println("Inmate's father's name:");
		String fname = sc.nextLine();
		if (name.matches("^[a-zA-Z ]*$") && (fname.matches("^[a-zA-Z ]*$"))) {
			System.out.println((name.concat(" " + fname)).toUpperCase());
		} else
			System.out.println("Invalid name");
	}
}
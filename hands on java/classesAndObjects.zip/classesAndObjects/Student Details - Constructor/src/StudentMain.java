import java.util.Scanner;

public class StudentMain
{
	public static void main(String []args)
	{
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Enter Students's Id:");
		int id=sc.nextInt();
		System.out.println("Enter Student's Name:");
		sc.nextLine();
		String name=sc.nextLine();
		System.out.println("Enter Student's address:");
		String address=sc.nextLine();
		Student stu=null;
		while(true)
		{
			System.out.println("Whether the student is from NIT(Yes/No):");
			String choice=sc.nextLine();
			if(choice.equals("yes")||choice.equals("YES"))
			{
				stu=new Student(id, name, address);
				break;
			}
			else if(choice.equals("no")||choice.equals("NO"))
			{
				System.out.println("Enter the college name:");
				String college=sc.nextLine();
				stu=new Student(id, name, address,college);
				break;
			}
			else
			{
				continue;
			}
		}
		
		System.out.println("Student id:"+stu.getStudentId());
		System.out.println("Student name:"+stu.getStudentName());
		System.out.println("Address:"+stu.getStudentAddress());
		System.out.println("College name:"+stu.getCollegeName());
	}
}
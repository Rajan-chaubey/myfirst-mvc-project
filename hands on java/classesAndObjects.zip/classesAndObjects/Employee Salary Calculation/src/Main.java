import java.util.Scanner;

public class Main{
	static Scanner sc=new Scanner(System.in);
	public static void main(String []args)
	{
		Employee emp=getEmployeeDetails();
		int pfpercentage=getPFPercentage();
		
		emp.calculateNetSalary(pfpercentage);
		
		System.out.println("Id:"+emp.getEmployeeId());
		System.out.println("Name:"+emp.getEmployeeName());
		System.out.println("Salary:"+emp.getSalary());
		System.out.println("Net Salary:"+emp.getNetSalary());
		
		
	}
	
	public static Employee getEmployeeDetails() 
	{
		Employee emp=new Employee();
		System.out.println("Enter Id:");
		emp.setEmployeeId(sc.nextInt());
		sc.nextLine();
		System.out.println("Enter Name:");
		emp.setEmployeeName(sc.nextLine());
		System.out.println("Enter salary:");
		emp.setSalary(sc.nextDouble());
		return emp;
	}
	
	public static int getPFPercentage()
	{
		System.out.println("Enter PF percentage:");
		int pfpercentage=sc.nextInt();
		return pfpercentage;
	}
}
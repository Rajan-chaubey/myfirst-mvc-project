import java.util.Scanner;

public class AccountDetails
{
	Scanner sc=new Scanner(System.in);
	Account acc=new Account();
	public Account getAccountDetails()
	{
		
		System.out.println("Enter account id:");
		acc.setAccountId(sc.nextInt());
		sc.nextLine();
		System.out.println("Enter account type:");
		acc.setAccountType(sc.nextLine());
		while(true)
		{
			System.out.println("Enter balance:");
			int balance=sc.nextInt();
			if(balance<=0)
			{
				System.out.println("Balance should be positive");
				continue;
			}
			else
			{
				acc.setBalance(balance);
				return acc;
			}
		}
		
	}
	
	public int getWithdrawAmount() 
	{
		System.out.println("Enter amount to be withdrawn:");
		int withdraw=sc.nextInt();
		while(true)
		{
			if(withdraw<=0)
			{
				System.out.println("Balance should be positive");
				continue;
			}
			else
			{
				acc.withdraw(withdraw);
				return withdraw;
			}
		}
		
	}
	
	public static void main(String []args)
	{
		AccountDetails obj=new AccountDetails();
		obj.getAccountDetails();
		obj.getWithdrawAmount();
	}
}
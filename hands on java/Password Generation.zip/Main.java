import java.util.Scanner;
public class Main{
	public static void main(String arg[]){
		Scanner sc= new Scanner(System.in);
		System.out.println("Generate your Security Code");
		String str=sc.next();
		if(str.matches("^(?=.*[A-Z])(?=.*[a-z])(?=.*[0-9])(?=.*[@#*])[A-Za-z0-9@#*]{8,}$"))
		{
			System.out.println("Security Code Generated Successfully");
		}
		else{
			System.out.println("Invalid Security Code, Try Again!");
		}
	}
}
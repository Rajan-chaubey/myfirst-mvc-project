import java.util.*;
public class PanCard{
	public static void main(String arg[]){
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter the PAN no:");
		String str=sc.next();
		if(str.matches("[A-Z]{5}[0-9]{4}[A-Z]{1}"))
		{
			System.out.println("Valid PAN no");
		}
		else{
			System.out.println("Invalid PAN no");
		}
	}
}
import java.util.Scanner;
public class UserMain{
	public static void main(String arg[]){
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter your ID");
		String str=sc.next();
		
		if(str.matches("^GBL/[0-9][0-9][0-9]/[0-9][0-9][0-9][0-9]$"))
		{
			System.out.println("Login success");
		}
		else{
			System.out.println("Incorrect ID");
		}
	}
}
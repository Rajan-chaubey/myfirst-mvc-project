

public interface Spatial {

}

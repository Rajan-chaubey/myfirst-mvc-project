import java.util.*;

public class Course {
	public static void main(String arg[]) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter no of course:");
		int n = sc.nextInt();
		sc.nextLine();
		int cnt=0;
		String str[] = new String[n];
		if (n <= 20 && n >= 1) {
			System.out.println("Enter course names:");
			for (int i = 0; i < n; i++) {
				str[i] = sc.nextLine();
			}
			System.out.println("Enter the course to be searched:");
			String search=sc.nextLine();
			for(int j=0;j<n;j++){
				if(str[j].equals(search)){
					cnt++;
					break;
				}
			}
			if(cnt==1){
				System.out.println(search+" course is available");
			}
			else{
				System.out.println(search+" course is not available");
			}
				
		}
		else{
			System.out.println("Invalid Range");
		}
	}
}
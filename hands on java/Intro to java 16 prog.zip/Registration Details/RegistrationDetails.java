import java.util.Scanner;

public class RegistrationDetails {
	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		System.out.println("Enter your name:");
		System.out.println("Enter your age:");
		System.out.println("Enter your phoneno:");
		System.out.println("Enter your qualification:");
		System.out.println("Enter your email id[Please provide valid id, after registering your registration id will be mailed]:");
	
		System.out.println("Enter your noofexperience[if any]");
		String name = s.nextLine();
		int age = s.nextInt();
	
		long phoneno = s.nextLong();
		s.nextLine();
		String qualification = s.nextLine();
		String email = s.nextLine();
		float noof = s.nextFloat();
		
		System.out.println("Dear " + name + ", Thanks for registering in our portal, registration id will be mailed to " + email + " within 2 working days");
		
	}
}
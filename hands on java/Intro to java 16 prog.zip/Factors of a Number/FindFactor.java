import java.util.Scanner;

public class FindFactor {
	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		int in = s.nextInt();
		if(in==0) {
			System.out.println("No Factors");
			System.exit(0);
		}
		int ign = Math.abs(in);
		
		for(int i = 1; i<=ign/2; i+=1) {
			if(ign%i==0) {
				System.out.print(i + ",");
			}
		}
		System.out.print(ign);
	}
}
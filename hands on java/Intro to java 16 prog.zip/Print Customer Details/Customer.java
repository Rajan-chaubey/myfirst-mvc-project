import java.util.*;
public class Customer {
    public static void main (String[] args) {
        
        String name,gender,city;
        int age;
        Scanner s = new Scanner(System.in);
        System.out.println("Enter your name:");
        name = s.nextLine();
        System.out.println("Enter age:");
        age = s.nextInt();
        s.nextLine();
        System.out.println("Enter gender:");
        gender = s.nextLine();
        System.out.println("Hailing from:");
        city = s.nextLine();
        
        System.out.println("Welcome, " + name + "! \nAge:" + age + "\nGender:" + gender + "\nCity:" + city);
        
    }
}
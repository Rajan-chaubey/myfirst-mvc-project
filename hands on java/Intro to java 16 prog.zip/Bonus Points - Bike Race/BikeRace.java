import java.util.Scanner;

public class BikeRace {
	public static void main(String[] args) {
		System.out.println("Enter the distance travelled");
		Scanner s = new Scanner(System.in);
		int distance = s.nextInt();
		int rem=0;
		if(distance<0) {
			System.out.println("Invalid Input");
			System.exit(0);
		}
		if(distance==0) {
			System.out.println("Your bonus points is 0");
			System.exit(0);
		}
		int i =0;
		int op=1,ep=1;
		while(distance>0) {
			rem = distance%10;
			distance = distance/10;
			i+=1;
			if(i%2==0) {
				op = op*rem;
			}
			else{
				ep = ep*rem;
			}
		}
		
		if(ep>op) {
			System.out.println("Your bonus points is " + ep);
		}
		else if(op>ep) {
			System.out.println("Your bonus points is " + op);
		}
		else {
			System.out.println("Your bonus points is " + ep*2);
		}
	}
}
import java.util.*;

public class Count {

	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		System.out.println("Enter the standard:");
		int std = s.nextInt();
		int result=0;
		if(std<=0 ||std>12) {
			System.out.println("Invalid Standard");
		}
		else {
			for(int i=1; i<=std;i+=1) {
				result = (int) (result + Math.pow(i, 2));
			}
			System.out.println("Nila gets " + result + " pencils");
		}
	}
}
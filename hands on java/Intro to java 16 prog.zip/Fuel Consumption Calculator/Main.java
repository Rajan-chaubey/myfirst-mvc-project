import java.util.*;

class Main{
    public static void main(String args[]) {
        Scanner s = new Scanner(System.in);
        System.out.println("Enter the no of liters to fill the tank ");
        double liter = s.nextInt();
        if(liter<=0){
            System.out.println((int)liter +" is an Invalid Input");
            System.exit(0);
        }
        System.out.println("Enter the distance covered");
        double distance = s.nextInt();
        if(distance<=0){
            System.out.println((int)distance +" is an Invalid Input");
            System.exit(0);
        }
        double avgCost;
        avgCost= (liter/distance)*100;
        
            System.out.println("Liters/100KM");
            System.out.printf("%.2f"+"\n",avgCost);
            double gal = liter* 0.2642;
            double miles = distance* 0.6214;
            double usSys = (miles/gal);
            System.out.println("Miles/gallons");
            System.out.printf("%.2f",usSys);
    }
}
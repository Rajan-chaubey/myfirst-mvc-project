import java.util.Scanner;

public class Palindrome {
	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		int in = s.nextInt();
		if(in<0) {
			System.out.println("Invalid Input");
			System.exit(0);
		}
		int reverse=0,original=in,rem=0;
		while(in!=0){
			rem = in%10;
			reverse = reverse*10 + rem;
			in=in/10;
		}
		if(reverse==original) {
			System.out.println("Palindrome");
		}
		else {
			System.out.println("Not a Palindrome");
		}
	}
}
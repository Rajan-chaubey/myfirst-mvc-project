import java.util.Scanner;

public class PrimeNumbers {
	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		int a = s.nextInt();
		int b = s.nextInt();
		if(a<=0||b<=0||a>b||a==b) {
			System.out.println("Provide valid input");
		}
		
		else {
			while(a<=b) {
				int r = 0;
				if(a==1) {
				    a=2;
				    continue;
				}
				for(int i=2;i<a;i++) {
					if(a%i==0) {
						r=1;
						break;
					}
				}
				if(r!=1) {
					System.out.print(a + " ");
				}
				r=0;
				a+=1;
			}
		}
	}
}
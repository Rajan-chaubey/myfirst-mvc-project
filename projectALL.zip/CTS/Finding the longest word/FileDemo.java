import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

public class FileDemo {
	public static void main(String[] args) {
		String s = null;
		String sp[];
		int length = 0;
		String longestWord=null;
		try {

			File f = new File("log.txt");
			BufferedReader br = new BufferedReader(new FileReader(f));
			while ((s = br.readLine()) != null) {
				sp = s.split(" ");

				for (int i = 0; i < sp.length; i++) {
					if (sp[i].length() > length) {
						length=sp[i].length();
						 longestWord = sp[i];
					}

				}

			}
			System.out.println(longestWord);

		} catch (IOException e) {
			e.printStackTrace();
		}

	}
}
import java.util.Scanner;

public class Main
{
	
	public static Hosteller getHostellerDetails()
	{
		Hosteller obj=new Hosteller();
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the Details:");
		System.out.println("Student Id");
		int sId=sc.nextInt();
		System.out.println("Student Name");
		sc.nextLine();
		String sName=sc.nextLine();
		System.out.println("Department Id");
		int dId=sc.nextInt();
		System.out.println("Gender");
		String gender=sc.next();
		System.out.println("Phone Number");
		String pNo=sc.next();
		System.out.println("Hostel Name");
		String hName=sc.next();
		System.out.println("Room Number");
		int rNo=sc.nextInt();
		
		obj.setStudentId(sId);
		obj.setName(sName);
		obj.setDepartmentId(dId);
		obj.setGender(gender);
		obj.setPhone(pNo);
		obj.setHostelName(hName);
		obj.setRoomNumber(rNo);
		
		return obj;
	}
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		Hosteller ob=new Hosteller();
	    ob=getHostellerDetails();
	    System.out.println("Modify Room Number(Y/N)");
	    String modR=sc.next();
	    if(modR.equals("Y"))
	    {
	    	System.out.println("New Room Number");
	    	int newRoomNo=sc.nextInt();
	    	ob.setRoomNumber(newRoomNo);
	    }
	    
	    System.out.println("Modify Phone Number(Y/N)");
	    String modP=sc.next();
	    if(modP.equals("Y"))
	    {
	    	System.out.println("New Phone Number");
	    	String newPhoneNumber=sc.next();
	    	ob.setPhone(newPhoneNumber);
	    }
	    System.out.println("The Student Details:");
	    System.out.print(ob.getStudentId()+" ");
	    System.out.print(ob.getName()+" ");
	    System.out.print(ob.getDepartmentId()+" ");
	    System.out.print(ob.getGender()+" ");
	    System.out.print(ob.getPhone()+" ");
	    System.out.print(ob.getHostelName()+" ");
	    System.out.print(ob.getRoomNumber()+" ");
	}
}
package com.spring.app;


public class Employee {
	private int empId;
	private String empName;
	Passport passObj;

}
	 	  	    	    	     	      	 	

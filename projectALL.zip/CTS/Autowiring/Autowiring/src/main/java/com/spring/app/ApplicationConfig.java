package com.spring.app;

public class ApplicationConfig {

	
}

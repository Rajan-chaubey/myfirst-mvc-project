package com.spring.app;



public class Driver {
public static void main(String[] args)
{
	ApplicationContext context=new ClassPathXmlApplicationContext("");
}
	
}

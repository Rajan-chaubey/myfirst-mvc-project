import java.util.Scanner;

public class StudentMain
{
	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Student's Id:");
		int sId=sc.nextInt();
		
		System.out.println("Enter Student's Name:");
		String sName=sc.next();
		
		System.out.println("Enter Student's address:");
		String sAddress=sc.next();
		
		String select;
		Student obj=null;;
		while(true)
		{
			System.out.println("Whether the student is from NIT(Yes/No):");
			 select=sc.next();
			if(select.equals("Yes") || select.equals("No") || select.equals("yes") || select.equals("no"))
			{
				break;
			}
			else
			{
				System.out.println("Wrong Input");
			}
		}
		if(select.equals("Yes") || select.equals("yes"))
		{
			 obj=new Student(sId,sName,sAddress);
			
		}
		
		else if(select.equals("No") || select.equals("no"))
		{
			System.out.println("Enter the college name:");
			String collName=sc.next();
			 obj=new Student(sId,sName,sAddress,collName);
			
		}
		
		System.out.println("Student id:"+obj.getStudentId());
		System.out.println("Student name:"+obj.getStudentName());
		System.out.println("Address:"+obj.getStudentAddress());
		System.out.println("College name:"+obj.getCollegeName());
		
	}
}
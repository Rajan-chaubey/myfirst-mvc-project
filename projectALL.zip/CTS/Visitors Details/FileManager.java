import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;



@SuppressWarnings("unchecked") // Do not delete this line
public class FileManager {

	static public File createFile() {
		File myObj = null;
		try {
			myObj = new File("visitors.txt");
			myObj.createNewFile();

		} catch (IOException e) {
			System.out.println("An error occurred.");
			e.printStackTrace();
		}
		return myObj;
	}

	static public void writeFile(File f, String record) {
		try {
			FileWriter myWriter = new FileWriter(f);
			myWriter.write(record);
			myWriter.close();
		} catch (IOException e) {
			System.out.println("An error occurred.");
			e.printStackTrace();
		}
	}

	static public String[] readFile(File f) {
		String s = null;
		String sp[] = null;
		try {
			BufferedReader br = new BufferedReader(new FileReader(f));
			while ((s = br.readLine()) != null) {
				sp = s.split(";");
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		return sp;
	}
}
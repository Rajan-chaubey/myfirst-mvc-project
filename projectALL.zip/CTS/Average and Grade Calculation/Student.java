public class Student
{
	private int id;
	private String name;
	private int [] marks=new int[];
	private float average;
	private char grade;
	
}
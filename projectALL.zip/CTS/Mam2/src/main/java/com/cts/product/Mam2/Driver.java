package com.cts.product.Mam2;


import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;


public class Driver {

	public static void main(String[] args) {
		ApplicationContext context= new ClassPathXmlApplicationContext("com/cts/product/Mam2/Bean.xml");
		Student obj=(Student)context.getBean("std");
		System.out.println(obj);
		
	}
}

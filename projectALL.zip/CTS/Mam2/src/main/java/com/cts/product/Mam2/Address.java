package com.cts.product.Mam2;

public class Address {
	private int houseNumber;
	private String StreetName;
	private String cityName;
	private int pinCode;
	
	
	public Address() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public Address(int houseNumber, String streetName, String cityName, int pinCode) {
		super();
		this.houseNumber = houseNumber;
		StreetName = streetName;
		this.cityName = cityName;
		this.pinCode = pinCode;
	}

	public int getHouseNumber() {
		return houseNumber;
	}
	public void setHouseNumber(int houseNumber) {
		this.houseNumber = houseNumber;
	}
	public String getStreetName() {
		return StreetName;
	}
	public void setStreetName(String streetName) {
		StreetName = streetName;
	}
	public String getCityName() {
		return cityName;
	}
	public void setCityName(String cityName) {
		this.cityName = cityName;
	}
	public int getPinCode() {
		return pinCode;
	}
	public void setPinCode(int pinCode) {
		this.pinCode = pinCode;
	}
	@Override
	public String toString() {
		return "Address [houseNumber=" + houseNumber + ", StreetName=" + StreetName + ", cityName=" + cityName
				+ ", pinCode=" + pinCode + "]";
	}
	
	
}

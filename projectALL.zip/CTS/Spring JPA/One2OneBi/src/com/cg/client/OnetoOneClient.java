package com.cg.client;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

import com.cg.beans.Address;
import com.cg.beans.Student;

public class OnetoOneClient {

	public static void main(String[] args) {
	EntityManagerFactory 	entityFactory=Persistence.createEntityManagerFactory("jpa");
	EntityManager entityManager=entityFactory.createEntityManager();
	EntityTransaction transaction=entityManager.getTransaction();
	transaction.begin();
		
	Address address3=new Address();
	address3.setStreet("55,6th crossRoad");
	address3.setCity("Mysore");
	address3.setPincode(999965);
	Student s2=new Student();
	s2.setName("riya");
	address3.setStudent(s2);
	s2.setAddress(address3);
	//entityManager.persist(address3);
	transaction.commit();
	System.out.println("Object saved");
	TypedQuery<Address> query=entityManager.
			createQuery("from Address",Address.class);
//	Address add=query.getSingleResult();
	//System.out.println(add);
	List<Address> addresslist=query.getResultList();
	for (Address address : addresslist) {
		System.out.println(address.getAddressId()+" "+
	address.getCity()+" "+address.getStreet()+" "+address.getPincode()+
	address.getStudent().getName());
	}
	}

}

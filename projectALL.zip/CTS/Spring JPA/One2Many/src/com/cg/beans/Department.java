package com.cg.beans;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="DEPT_DETAIL")
public class Department implements Serializable{
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="myseq")
	@SequenceGenerator(name="myseq",sequenceName="deptdetailseq",
	initialValue=10,allocationSize=1)
	@Column(length=5)
	private int id;
	@Column(length=20)
	private String name;
	@OneToMany(cascade=CascadeType.ALL)
	private Set<Employee> employees=new HashSet<>();
	
	public Department() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public Department(String name, Set<Employee> employees) {
		super();
		this.name = name;
		this.employees = employees;
	}

	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Set<Employee> getEmployees() {
		return employees;
	}
	public void setEmployees(Set<Employee> employees) {
		this.employees = employees;
	}
	@Override
	public String toString() {
		return "Department [id=" + id + ", name=" + name + ", employees=" + employees + "]";
	}
	
	
}

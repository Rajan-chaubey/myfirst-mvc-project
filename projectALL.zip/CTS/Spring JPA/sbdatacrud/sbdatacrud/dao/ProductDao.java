package com.tr.dao;

import java.util.List;
import java.util.Map;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.tr.model.Product;

@Repository
public interface ProductDao extends JpaRepository<Product,Integer> {
	//boolean save(Product product);
	//boolean delete(int pid);
	//boolean update(Product product);
	//Product getById(int pid);
	//List<Product> getAllProducts();
	
	
}

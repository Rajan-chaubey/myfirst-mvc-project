package com.tr.controller;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.tr.dao.ProductDao;
import com.tr.model.Product;

@Controller
public class ProductController {
	@Autowired
	ProductDao productDao;
	
	@RequestMapping("/productform")
	public String showproductform(@ModelAttribute("product")  Product product) {
		product=new Product();
		
		return "productform";
	}
	
	@RequestMapping("/save")
	public String addProduct(@Valid @ModelAttribute("product")  Product product,
			BindingResult bindingResult) {
		System.out.println(bindingResult.hasErrors());
		if(bindingResult.hasErrors()) {
			System.out.println("ui details not correct");
			return "productform";
		}
	productDao.save(product);
	return "redirect:/viewproduct";
	}
	
	@RequestMapping("/viewproduct")
	public String viewallProduct(Model m) {
		
		List<Product> productlist=productDao.findAll();
		m.addAttribute("plist",productlist);
		return "viewproduct";
	}
	
	@RequestMapping("/updateform")
	public String updateform(@RequestParam int pid,@ModelAttribute("product")  Product product) {
		Optional<Product> pp=productDao.findById(pid);
		product=pp.get();
		return "updateform";
	}
	@RequestMapping("/delete")
	public String delete(@RequestParam int pid) {
		productDao.deleteById(pid);
		return "redirect:/viewproduct";
	}
	@RequestMapping("/update")
	public String updateProduct(@ModelAttribute("product") Product product) {
	productDao.save(product);
	return "redirect:/viewproduct";
	}
}

package com.tr;

import com.tr.dao.StudentDao;
import com.tr.entity.Student;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
      StudentDao dao=new StudentDao();
      Student s1=new Student("priya", "priya@gmail.com",123456);
      Student s2=new Student("sriya", "sriya@gmail.com",55567);
      Student s3=new Student("diya", "diya@gmail.com",1234568);
dao.addStudent(s1);
dao.addStudent(s2);
dao.addStudent(s3);
      
      //dao.updateStudent(s2,s1);
      dao.deleteStudent(3);
    }
}

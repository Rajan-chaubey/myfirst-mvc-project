package com.tr.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import com.tr.entity.Student;

public class StudentDao {

	EntityManagerFactory factory;
	EntityManager manager;
	
	public StudentDao() {
	factory=Persistence.createEntityManagerFactory("jpa");
	manager=factory.createEntityManager();
	}
	
	public void addStudent(Student s){
		EntityTransaction tr=manager.getTransaction();
		tr.begin();
		manager.persist(s);
		tr.commit();
	}
	public void updateStudent(Student s,Student s1){
		System.out.println("dao"+s);
		EntityTransaction tr=manager.getTransaction();
		tr.begin();
		Query query=manager.createQuery(
				"select s from Student s where s.studId=?1");
			query.setParameter(1, s.getStudId());
			Student st=(Student) query.getSingleResult();
		System.out.println("st"+st);
		st.setEmail("kkk@gmail.com");
		st.setPhone(999999);
		manager.merge(st);
		tr.commit();
	}
	
	public void deleteStudent(int sid){
		EntityTransaction tr=manager.getTransaction();
		tr.begin();
		Query query=manager.createQuery(
			"select s from Student s where s.studId=?1");
		query.setParameter(1, sid);
		Student st=(Student) query.getSingleResult();
		manager.remove(st);
		tr.commit();
	}
	
	public List<Student> getAllStudent(){
		TypedQuery<Student> q =manager.createQuery(
				"from Student", Student.class);
		List<Student> studList=q.getResultList();
		return studList;
	}
}

package com.tr.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Student implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int studId;
	@Column(name="stud_name",nullable=false)
	private String name;
	@Column(unique=true)
	private String email;
	private long phone;
public Student() {
	// TODO Auto-generated constructor stub
}
public Student(int studId, String name, String email, long phone) {
	super();
	this.studId = studId;
	this.name = name;
	this.email = email;
	this.phone = phone;
}
public Student(String name, String email, long phone) {
	super();
	this.name = name;
	this.email = email;
	this.phone = phone;
}
public int getStudId() {
	return studId;
}
public void setStudId(int studId) {
	this.studId = studId;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getEmail() {
	return email;
}
public void setEmail(String email) {
	this.email = email;
}
public long getPhone() {
	return phone;
}
public void setPhone(long phone) {
	this.phone = phone;
}
@Override
public String toString() {
	return "Student [studId=" + studId + ", name=" + name + ", email=" + email + ", phone=" + phone + "]";
}




	

}

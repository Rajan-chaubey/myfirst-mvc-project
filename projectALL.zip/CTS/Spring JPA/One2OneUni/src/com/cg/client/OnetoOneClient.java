package com.cg.client;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.cg.beans.Address;
import com.cg.beans.Student;

public class OnetoOneClient {

	public static void main(String[] args) {
	EntityManagerFactory 	entityFactory=Persistence.createEntityManagerFactory("jpa");
	EntityManager entityManager=entityFactory.createEntityManager();
	EntityTransaction transaction=entityManager.getTransaction();
	transaction.begin();
	Address address1=new Address(
		"#27,8thcross,S.R.Nagar","bangalore",560025);
	Student student1=new Student();
	student1.setName("priya");
	student1.setAddress(address1);
	entityManager.persist(student1);
	transaction.commit();
	System.out.println("Object saved");

	}

}

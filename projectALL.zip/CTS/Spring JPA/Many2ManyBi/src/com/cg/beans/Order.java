package com.cg.beans;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name="order1")
public class Order {
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="myseq")
	@SequenceGenerator(name="myseq",sequenceName="orderseq",
	initialValue=100,allocationSize=1)
	@Column(length=5)
	private int id;
	@Temporal(TemporalType.DATE)
	private Date orderDate;
	@ManyToMany(cascade=CascadeType.ALL)
	@JoinTable(name="productorder",
	joinColumns= {@JoinColumn(name="orderid")},
	inverseJoinColumns= {@JoinColumn(name="productid")})
	private Set<Product> products=new HashSet<>();
	
	public void addProduct(Product p) {
		this.getProducts().add(p);
	}

	public Order() {
		super();
		// TODO Auto-generated constructor stub
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Date getOrderDate() {
		return orderDate;
	}

	public void setOrderDate(Date orderDate) {
		this.orderDate = orderDate;
	}

	public Set<Product> getProducts() {
		return products;
	}

	public void setProducts(Set<Product> products) {
		this.products = products;
	}

	@Override
	public String toString() {
		return "Order [id=" + id + ", orderDate=" + orderDate + ", products=" + products + "]";
	}
	
	
	
}

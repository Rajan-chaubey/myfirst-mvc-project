import java.util.Scanner;

public class TestApplication {

	public static void main(String[] args) {
	    Scanner s = new Scanner(System.in);
	    AddressBook add = new AddressBook();
	    AddressBook.Address obj = add.new Address();
	    System.out.println("Enter the permanent address");
	    System.out.println("Enter the house name");
	    String name = s.nextLine();
	    System.out.println("Enter the street");
	    String street = s.nextLine();
	    System.out.println("Enter the city");
	    String city= s.nextLine();
	    System.out.println("Enter the state");
	    String state = s.nextLine();
	    
	    System.out.println("Enter the temporary address");
	    System.out.println("Enter the house name");
	    String name2 = s.nextLine();
	    System.out.println("Enter the street");
	    String street2 = s.nextLine();
	    System.out.println("Enter the city");
	    String city2 = s.nextLine();
	    System.out.println("Enter the state");
	    String state2 = s.nextLine();
	    
	    System.out.println("Enter the phone number");
	    long phone =s.nextLong();
	    
	    obj.setName(name);
	    obj.setStreet(street);
	    obj.setCity(city);
	    obj.setState(state);
	    
	    System.out.println("Permanent address");
	    System.out.println("House name:"+name);
	    System.out.println("Street:"+street);
	    System.out.println("City:"+city);
	    System.out.println("State:"+state);
	    
	    obj.setName(name2);
	    obj.setStreet(street2);
	    obj.setCity(city2);
	    obj.setState(state2);
	    add.setPhoneNumber(phone);
	    System.out.println("Temporary address");
	    System.out.println("House name:"+name2);
	    System.out.println("Street:"+street2);
	    System.out.println("City:"+city2);
	    System.out.println("State:"+state2);
	    
	    
	    
	    System.out.println("Phone number");
	    System.out.println(phone);
	    
	    
	    
	    
	    
	    
	}
}
package com.calculator;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CalculatorApplicationTests {

	void contextLoads() {
	}

}

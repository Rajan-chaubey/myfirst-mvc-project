package com.model;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;

public class Product {
	@NotNull(message = "{price.not.empty}")
	@Min(value = 1, message = "{price.min.value}")
	private Double productPrice;
	private String productType;

	public Double getProductPrice() {
		return productPrice;
	}

	public void setProductPrice(Double productPrice) {
		this.productPrice = productPrice;
	}

	public String getProductType() {
		return productType;
	}

	public void setProductType(String productType) {
		this.productType = productType;
	}

}

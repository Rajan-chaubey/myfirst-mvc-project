package com.service;

import com.model.Product;

public interface DiscountService {
	public double calculateDiscount(Product product);

}

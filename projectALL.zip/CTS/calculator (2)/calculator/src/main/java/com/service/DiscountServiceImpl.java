package com.service;

import org.springframework.stereotype.Service;

import com.model.Product;

@Service
public class DiscountServiceImpl implements DiscountService {

	@Override
	public double calculateDiscount(Product product) {
		if (product.getProductType().equalsIgnoreCase("Electronic"))
			return (product.getProductPrice() - (product.getProductPrice() * 0.25));
		else if (product.getProductType().equalsIgnoreCase("Apparels"))
			return (product.getProductPrice() - (product.getProductPrice() * 0.1));
		else
			return (product.getProductPrice() - (product.getProductPrice() * 0.5));
	}

}

package com.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.validation.Validator;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.model.Product;
import com.service.DiscountService;
import com.service.DiscountServiceImpl;

@Controller
public class DiscountController {
	@Autowired
	private DiscountService discountService;
	@Autowired
	Validator validator;

	@RequestMapping(value = "/getDiscountedPrice", method = RequestMethod.GET)
	public String discountPage(@ModelAttribute("product") Product product) {
		product = new Product();
		return "calculatediscount";
	}

	@RequestMapping(value = "/calculateDiscountedPrice", method = RequestMethod.GET)
	public String calculateDiscount(@ModelAttribute("product") Product product, ModelMap model, BindingResult result) {
		validator.validate(product, result);
		if(result.hasErrors()){
			return "calculatediscount";
		}
		double discount = discountService.calculateDiscount(product);
		model.addAttribute("discount", discount);
		return "finalprice";
	}

	@ModelAttribute("productTypeList")
	public List<String> populateProductType() {
		List<String> productTypeList = new ArrayList<String>();
		productTypeList.add("Electronic");
		productTypeList.add("Apparels");
		productTypeList.add("Toys");
		return productTypeList;
	}

}

package com.spring.app;


public class MemberShip {
	
	private int membership;
	private String membershipType;
	private int visitsPerYear;
	private Customer customer;
	public MemberShip(int membership, String membershipType, int visitsPerYear, Customer customer) {
		super();
		this.membership = membership;
		this.membershipType = membershipType;
		this.visitsPerYear = visitsPerYear;
		this.customer = customer;
	}
	public int getMembership() {
		return membership;
	}
	public void setMembership(int membership) {
		this.membership = membership;
	}
	public String getMembershipType() {
		return membershipType;
	}
	public void setMembershipType(String membershipType) {
		this.membershipType = membershipType;
	}
	public int getVisitsPerYear() {
		return visitsPerYear;
	}
	public void setVisitsPerYear(int visitsPerYear) {
		this.visitsPerYear = visitsPerYear;
	}
	public Customer getCustomer() {
		return customer;
	}
	public void setCustomer(Customer customer) {
		this.customer = customer;
	}
	
}	 	  	    	    	     	      	 	

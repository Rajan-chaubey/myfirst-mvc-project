package com.validate;

import org.springframework.stereotype.Service;
import org.springframework.validation.Errors;

import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;
import com.model.RegistrationBean;

@Service
public class CustomValidator implements Validator {

	public void validate(Object arg0, Errors arg1) {
		ValidationUtils.rejectIfEmpty(arg1, "userName", "userName.required", "User Name cannot be blank");
		ValidationUtils.rejectIfEmptyOrWhitespace(arg1, "contactNumber", "contactNumber.required",
				"Contact Number should be of 10 digits/Contact Number should be cannot be blank");
		ValidationUtils.rejectIfEmptyOrWhitespace(arg1, "emailId", "emailId.required", "Email ID cannot be blank");
		ValidationUtils.rejectIfEmptyOrWhitespace(arg1, "confirmEmailId", "confirmEmailId.required",
				"Confirm Email ID cannot be blank");
		ValidationUtils.rejectIfEmpty(arg1, "status", "status.required",
				"please agree to the terms and conditions cannot be blank");
		RegistrationBean registrationBean = (RegistrationBean) arg0;

		String phoneNo = registrationBean.getContactNumber() + "";
		if (!phoneNo.matches("[[7-9][0-9]{9}")) {
			arg1.rejectValue("contactNumber", "contactNumber.length",
					"Contact Number should be of 10 digits/Contact Number should be cannot be blank");

		}
		if (!registrationBean.getEmailId().matches(
				"^[a-zA-Z0-9_+&*-]+(?:\\." + "[a-zA-Z0-9_+&*-]+)*@" + "(?:[a-zA-Z0-9-]+\\.)+[a-z" + "A-Z]{2,7}$")) {
			arg1.rejectValue("emailId", "emailId.lenght", "Should be a proper ID format");

		}
		if (!registrationBean.getConfirmEmailId().matches(
				"^[a-zA-Z0-9_+&*-]+(?:\\." + "[a-zA-Z0-9_+&*-]+)*@" + "(?:[a-zA-Z0-9-]+\\.)+[a-z" + "A-Z]{2,7}$")) {
			arg1.rejectValue("confirmEmailId", "confirmEmailId.lenght", "Should be a proper ID format");

		}
		if (!registrationBean.getEmailId().equalsIgnoreCase(registrationBean.getConfirmEmailId())) {
			arg1.rejectValue("confirmEmailId", "confirmEmailId.lenght", "Email and Confirm Email should be a same");

		}

		if (registrationBean.isStatus() == false) {
			arg1.rejectValue("status", "status.lenght", "please agree to the terms and conditions");

		}

	}

	public boolean supports(Class<?> arg0) {
		// TODO Auto-generated method stub

		return RegistrationBean.class.equals(arg0);

	}

}

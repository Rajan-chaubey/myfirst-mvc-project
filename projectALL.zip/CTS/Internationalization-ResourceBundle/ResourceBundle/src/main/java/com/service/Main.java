package com.service;
import java.util.Locale;
import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
 import java.util.Scanner;
public class Main {
 
	
	@SuppressWarnings("resource")
	public static void main(String[] args) {
		ApplicationContext context = new ClassPathXmlApplicationContext("beans.xml");
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the String");
		String s1=sc.nextLine();
		System.out.println("Enter the Language(Chinese/French/German)");
		String s2=sc.next();	

		String str[]=s1.split(" ");
		for(int i=0; i<str.length; i++)
		{
			System.out.print(str[i]);
			System.out.print(" in "+s2+" ");
		}


	       
	}
}
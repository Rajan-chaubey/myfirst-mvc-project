package com.spring.app;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Driver {
	
public static void main(String[] args)
{
	ApplicationContext context = new ClassPathXmlApplicationContext("beans.xml");
	
	CurrencyConverter c=(CurrencyConverter) context.getBean("a");
	
	System.out.println(c.getTotalCurrencyValue("5DINAR"));
}

}

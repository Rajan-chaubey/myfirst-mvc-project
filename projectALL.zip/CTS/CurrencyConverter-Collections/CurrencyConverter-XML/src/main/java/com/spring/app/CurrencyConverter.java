package com.spring.app;

//import java.security.KeyStore.Entry;
import java.util.Map;
import java.util.Set;

import java.util.Iterator;

import java.util.Map.Entry;

public class CurrencyConverter {

	private Map<String, String> mObj;

	public Map<String, String> getmObj() {
		return mObj;
	}

	public void setmObj(Map<String, String> mObj) {
		this.mObj = mObj;
	}

	public int getTotalCurrencyValue(String value) {

		int total=0;
		StringBuffer alpha = new StringBuffer(),   num = new StringBuffer();
		       
		 for (int i=0; i<value.length(); i++) 
	        { 
	            if (Character.isDigit(value.charAt(i))) 
	                num.append(value.charAt(i)); 
	            
	            else if(Character.isAlphabetic(value.charAt(i)))
	                alpha.append(value.charAt(i)); 
	             
	        } 
		 
		Set<Entry<String, String>> set = mObj.entrySet();
		Iterator<Entry<String, String>> itr = set.iterator();
		while (itr.hasNext()) {
			Entry<String, String> entry = itr.next();
			String str1 = num.toString();
			String str2 = alpha.toString();
			if(str2.equals(entry.getKey()))
			{
				int c=Integer.parseInt(entry.getValue());
				int z=Integer.parseInt(str1);
				total=c*z;
			}
			

		}
		return total;

	}

}

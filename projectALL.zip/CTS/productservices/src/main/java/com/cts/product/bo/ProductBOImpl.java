package com.cts.product.bo;

import com.cts.product.dao.ProductDAO;
import com.cts.product.dto.Product;

public class ProductBOImpl implements ProductBO {

	private ProductDAO dao;
	//@Override
	public void create(Product product) {
		getDao().create(product);

	}

	//@Override
	public Product findProduct(int id) {
		
		return dao.read(id);
	}

	public ProductDAO getDao() {
		return dao;
	}

	public void setDao(ProductDAO dao) {
		this.dao = dao;
	}

}

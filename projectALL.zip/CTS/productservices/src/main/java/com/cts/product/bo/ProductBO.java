package com.cts.product.bo;

import com.cts.product.dto.Product;

public interface ProductBO {

	public void create(Product product);
	
	public Product findProduct(int id);
}

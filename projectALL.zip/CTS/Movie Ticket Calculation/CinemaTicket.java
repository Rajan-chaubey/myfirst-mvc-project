import java.util.Scanner;

public class CinemaTicket
{
	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		float total=0;
		float tot_ref=0;
		
		System.out.println("Enter the no of ticket:");
		int noTicket=sc.nextInt();
		if(noTicket <5 || noTicket>40)
		{
			System.out.println("Minimum of 5 and Maximum of 40 Tickets");
			System.exit(0);
		}
		System.out.println("Do you want refreshment:");
		String refreshment=sc.next();
		
		System.out.println("Do you have coupon code:");
		String code=sc.next();
		
		System.out.println("Enter the circle:");
		String circle=sc.next();
		if( (circle.equals("k") || circle.equals("q"))==false )
		{
			System.out.println("Invalid Input");
			System.exit(0);
		}
		if(circle.equals("k"))
		{
			 total=noTicket*75;
		}
		if(circle.equals("q"))
		{
			 total=noTicket*150;
		}
		if(refreshment.equals("y"))
		{
		 tot_ref=noTicket*50;
		}
		float discount=0;
		if(noTicket>20)
		{
		discount=(total*10)/100;
		total=total-discount;
		}
		if(code.equals("y"))
		{
			discount=(total*2)/100;
			total=total-discount;
		}
		total=total+tot_ref;
		System.out.print("Ticket cost:"+String.format("%.2f", total));
		
		
		
		
		
		
	}
}
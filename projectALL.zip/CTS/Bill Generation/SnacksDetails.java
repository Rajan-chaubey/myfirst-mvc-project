import java.util.Scanner;

public class SnacksDetails
{
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the no of pizzas bought:");
		int i=sc.nextInt();
		int total=i*100;
		System.out.println("Enter the no of puffs bought:");
		int j=sc.nextInt();
		total=total+(j*20);
		System.out.println("Enter the no of cool drinks bought:");
		int k=sc.nextInt();
		total=total+(k*10);
		System.out.println("Bill Details");
		System.out.println("No of pizzas:"+i);
		System.out.println("No of puffs:"+j);
		System.out.println("No of cooldrinks:"+k);
		System.out.println("Total price="+total);
		System.out.println("ENJOY THE SHOW!!!");
	}
}
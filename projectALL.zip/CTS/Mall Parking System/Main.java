import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);

		Date inTime = null;
		Date outTime = null;
		Date today = null;

		SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy HH:mm");

		try {
			String td = "29/10/2019 20:10";
			today = format.parse(td);

		} catch (ParseException e) {
			e.printStackTrace();
		}

		System.out.println("In-time");

		String s1 = sc.nextLine();
		try {
			inTime = format.parse(s1);

			if (inTime.compareTo(today) > 0 || inTime.compareTo(today) == 0) {
				System.out.println(s1 + " is an Invalid In-Time");
				System.exit(0);
			}

		} catch (ParseException e) {

			System.out.println(s1 + " is an Invalid In-Time");
			System.exit(0);
		}

		System.out.println("Out-time");

		String s2 = sc.nextLine();
		try {
			outTime = format.parse(s2);
			if (outTime.compareTo(inTime) < 0 || outTime.compareTo(inTime) == 0) {
				System.out.println(s2 + " is an Invalid Out-Time");
				System.exit(0);
			}

		} catch (ParseException e) {
			System.out.println(s2 + " is an Invalid Out-Time");
			System.exit(0);
		}

		long diff = outTime.getTime() - inTime.getTime();
		long difhrs = diff / (60 * 60 * 1000);
		long rs = difhrs * 10;

		long temp = diff % 3600000;
		if (temp != 0) {
			rs = rs + 10;
		}

		System.out.println(rs + " Rupees");
	}
}

package com.ui;
import com.utility.*;
import java.util.*;

public class UserInterface {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc =new Scanner(System.in);
		//Fill the UI code
		int policyId;
		String policyName,policyType;
		Map<Integer, String> tree_map =  new TreeMap<Integer, String>(); 
        
		Bazaar bz=new Bazaar();
		System.out.println("Enter the no of Policy names you want to store ");
		int num=sc.nextInt();
		for(int i=1; i<=num; i++)
		{
			System.out.println("Enter the Policy ID ");
			policyId=sc.nextInt();
			sc.nextLine(); 
			System.out.println("Enter the Policy Name ");
			policyName=sc.nextLine();
			bz.addPolicyDetails(policyId, policyName);
		}
		
		tree_map= bz.getPolicyMap();
		System.out.println(tree_map);
		 for (Map.Entry m:tree_map.entrySet()) 
	          System.out.println(m.getKey() +" "+ m.getValue()); 
	                             
		
		
		
		
		List<Integer> ll= new ArrayList<Integer>();
		System.out.println("Enter the policy type to be searched ");
		policyType=sc.next();
		ll=bz.searchBasedOnPolicyType(policyType);
		for(int value:ll)
		{
			System.out.println(value);
		}
	}
   
}

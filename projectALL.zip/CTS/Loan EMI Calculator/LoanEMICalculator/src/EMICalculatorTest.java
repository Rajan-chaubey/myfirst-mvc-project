import static org.junit.Assert.assertEquals;
import java.util.*;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;

@RunWith(Parameterized.class)
public class EMICalculatorTest {

     

     double principal;
     String loanType;
     double durationInYears;
     double loanAmount;
     EMICalculator emiCalculator;

     public EMICalculatorTest(double principal,String loanType,double durationInYears,double loanAmount)
     {
         this.principal=principal;
         this.loanType=loanType;
         this.durationInYears=durationInYears;
         this.loanAmount=loanAmount;
     }


     @Parameterized.Parameters
     public static Collection EMICalc()
     {
     return Arrays.asList(new Object[][]
     {
     {10000.0,"Housing Loan",20.0,42.17074984609382},
     {10000.0,"Vehicle Loan",20.0,42.128590158057385},
     {10000.0,"Personal Loan",20.0,42.08645824204558},
     {10000.0,"Personal Loan",29.0,0.0}

     });

     }

     @Test
     public void testCalculateEMI()
     {
         emiCalculator= new EMICalculator(); 
         assertEquals(loanAmount,emiCalculator.calculateEMI(principal,loanType,durationInYears),0.0);
         
      
     }

}



    
	
	

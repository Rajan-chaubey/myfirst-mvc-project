import java.util.Scanner;

public class Division
{
	
	public String divideTwoNumbers(int number1 ,int number2)
	{
		String str="";
		
			try{
				  int result=number1/number2;
			     str=str +"The answer is "+result+ "."+ str;
			 }
			catch(ArithmeticException e)
			{
				
				str=str+" Division by zero is not possible.";
			
			}
			finally
			{
				str=str + " Thanks for using the application.";
			}
			return str;
		}

		  

		
	
	
	
public static void main(String[] args) {
		
		Division ob=new Division();
		System.out.println("Enter the numbers");
		Scanner sc=new Scanner(System.in);
		int number1=sc.nextInt();
		int number2=sc.nextInt();
		
		String s=ob.divideTwoNumbers(number1,number2);
		System.out.println(s);
		 
		
		
		
				
	}
	
	
}
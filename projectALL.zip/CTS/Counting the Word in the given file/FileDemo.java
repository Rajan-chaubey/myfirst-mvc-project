import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.BufferedReader;

public class FileDemo {
	public static void main(String[] args) {

		String s = null;
		String sp[];
		int count = 0;

		try {

			File f = new File("log.txt");
			BufferedReader br = new BufferedReader(new FileReader(f));
			while ((s = br.readLine()) != null) {
				sp = s.split(" ");

				for (int i = 0; i < sp.length; i++) {
					if (sp[i].equalsIgnoreCase("knowledge")) {
						count++;
					}

				}

			}
			System.out.println(count);

		} catch (IOException e) {
			e.printStackTrace();
		}

	}

}

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

public class FileDemo
{
    public static void main(String[] args)
    {
        
    	String s = null;
		String sp[];
		int count = 0;

		try {
			
			 File f = new File("log.txt"); 
			 BufferedReader br = new BufferedReader(new FileReader(f)); 
			 while ((s = br.readLine()) != null) {
				   System.out.println(s);
			 }
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

    
}
import org.junit.Test;
import static org.junit.Assert.fail;
import static org.junit.Assert.*;

public class ProductTest {

 //Write the code for test methods
	Product product=new Product("123","Apple",20);
	Product product1=new Product("124","Mango",21);
	Product product2=new Product();
	ProductDAO prod=new ProductDAO();
	@Test
	public void testAddProduct(){
		assertTrue(prod.addProduct(product));
	}
	@Test
	public void testAddProductEmpty(){
		product2.setPrice(25);
		product2.setProductId("SBM");
		product2.setProductName("MacBook");
		assertTrue(prod.addProduct(product2));
	}
	@Test
	public void testAddProductNull()
	{
		assertFalse(prod.addProduct(null));
	}
	@Test
	public void testDeleteProductTrue(){
		prod.addProduct(product);
		assertTrue(prod.deleteProduct(product));
	}
	@Test
	public void testDeleteProductNull(){
		prod.addProduct(product);
		assertFalse(prod.deleteProduct(null));
	}
	@Test
	public void testDeleteProductEmpty(){
		product2.setPrice(25);
		product2.setProductName("dsg");
		product2.setProductId("12");
		prod.addProduct(product2);
		assertTrue(prod.deleteProduct(product2));
	}
	
	
	
	
	
	
}

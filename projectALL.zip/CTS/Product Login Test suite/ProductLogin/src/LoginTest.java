import org.junit.Test;
import static org.junit.Assert.fail;

import org.junit.Assert;

import static org.junit.Assert.*;


public class LoginTest {

      
    	    	 
      //Write the code for adding and deleting Login data
	Login login=new Login("123","pass");
	Login login1=new Login("1234","pass");
	LoginDAO log=new LoginDAO();
	@Test
	public void testAddLogin()
	{
		assertTrue(log.addLogin(login));
	}
	@Test
	public void testAddLoginNull(){
		assertFalse(log.addLogin(null));
	}
	@Test
	public void testDeleteLoginFalse(){
		assertFalse(log.deleteLogin(login1));
	}
	@Test
	public void testDeleteLoginTrue(){
		log.addLogin(login);
		assertTrue(log.deleteLogin(login));
	}
	@Test
	public void testDeleteLoginFalseNull(){
		assertFalse(log.deleteLogin(null));
	}
	
}


import org.junit.Assert;
import org.junit.Test;

public class CustomerTest {
	//Write the code for testing assertion using JUNIT


Customer customer = new Customer("480828860977","shubh","srivastava","saket nagar",123456789,"shubhamsriv98@gmail.com");

@Test
public void isValidAadharNoTestForTrue(){
     
    Assert.assertTrue(customer.isValidAadharNo("480828860977"));
}

@Test
public void isValidAadharNoTestForFalse(){
   
      Assert.assertFalse(customer.isValidAadharNo("080828860977"));
   
}

@Test
      public void  firstAndLastNameNotEqual(){
     Assert.assertNotEquals(customer.getFirstName(),customer.getLastName());
}

@Test
    public void emailIDIsNotNull(){
      Assert.assertNotNull(customer.getEmailId());
}

}
import java.sql.Connection;
import java.sql.PreparedStatement;

public class FlightManagementSystem
{
	static PreparedStatement statement;
	public boolean addFlight(Flight flightObj)
	{
		try(Connection connection = DB.getConnection())
		{
			statement =connection.prepareStatement("insert into flight values(?,?,?,?,?)");
			statement.setInt(1,flightObj.getFlightId());
			statement.setString(2,flightObj.getSource());
			statement.setString(3,flightObj.getDestination());
			statement.setInt(4,flightObj.getNoOfSeats());
			statement.setDouble(5,flightObj.getFlightFare());
			statement.executeUpdate();
			
			return true;
		}
		catch(Exception e)
		{
			e.printStackTrace();
			return false;
		}
		
	}
}
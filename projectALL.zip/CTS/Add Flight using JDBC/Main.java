import java.util.*;
public class Main{
    public static void main(String[] args){
        Scanner sc=new Scanner(System.in);
        
        int flightId=sc.nextInt();
        String source=sc.next();
        String destination=sc.next();
        int noOfSeats=sc.nextInt();
        double flightFare=sc.nextDouble();
        
        Flight ob=new Flight(flightId,source,destination,noOfSeats,flightFare);
       
        FlightManagementSystem ob1=new FlightManagementSystem();
        boolean check=ob1.addFlight(ob);
        if(check)
        {
        	System.out.println("â€œFlight details added successfullyâ€");
        }
        else
        {
        	System.out.println("â€œAddition not doneâ€.");
        }
    }
}
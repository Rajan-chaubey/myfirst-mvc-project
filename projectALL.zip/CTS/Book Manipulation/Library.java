import java.util.ArrayList;

public class Library
{
	private ArrayList<Book> bookList=new ArrayList<Book>();

	public ArrayList<Book> getBookList() {
		return bookList;
	}

	public void setBookList(ArrayList<Book> bookList) {
		this.bookList = bookList;
	}
	
	public void addBook(Book bobj)
	{	//bookList.addAll(getBookList());
		setBookList(getBookList());
		bookList.add(bobj);
		System.out.println(getBookList());
		
	}
	public boolean isEmpty()
	{
		if(bookList.isEmpty())
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	
	public ArrayList<Book> viewAllBooks()
	{
		return bookList;
	}
	public ArrayList<Book> viewBooksByAuthor(String author)
	{
		return bookList;
	}
	
	public int countnoofbooks(String bname)
	{
		int count=0;
		for(Book book: bookList)
		{
			if( (book.getBookName()).equals(bname))
				count++;
		}
		return count;
	}
}
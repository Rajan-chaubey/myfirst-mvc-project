import java.util.Scanner;
import java.util.ArrayList;
public class Main
{
	public static void main(String args[])
	{
		
		ArrayList<Book> bkList=new ArrayList<Book>();
		ArrayList<Book> bkList1=new ArrayList<Book>();
		Library lb=new Library();
		Book b=new Book();
		while(true)
		{
			System.out.println("1.Add Book");
			System.out.println("2.Display all book details");
			System.out.println("3.Search Book by author");
			System.out.println("4.Count number of books - by book name");
			System.out.println("5.Exit");
			System.out.println("Enter your choice:");
			Scanner sc=new Scanner(System.in);
			int i=sc.nextInt();
			switch(i)
			{
				case 1:{
					System.out.println("Enter the isbn no:");
					int isbn=sc.nextInt();
					System.out.println("Enter the book name:");
					String name=sc.next();
					System.out.println("Enter the author name:");
					String author=sc.nextLine();
					sc.nextLine();
					b.setIsbnno(isbn);
					b.setBookName(name);
					b.setAuthor(author);
					lb.addBook(b);
					}
					break;
				case 2:
					bkList=lb.viewAllBooks();
					for(Book ob1:bkList)
					{
						System.out.println("Book name:"+ob1.getBookName());
					}
					break;
				case 3:
					System.out.println("Enter the author name:");
					String author_name=sc.nextLine();
					bkList=lb.viewBooksByAuthor(author_name);
					for(Book ob2: bkList)
					{
						if( (ob2.getAuthor())==author_name )
						{
							System.out.println("ISBN no:"+ob2.getIsbnno());
							System.out.println("Book name:"+ob2.getBookName());
							System.out.println("Author name:"+ob2.getAuthor());
						}
					}
					break;
				case 4:
					String bj=sc.next();
					int no=lb.countnoofbooks(bj);
					System.out.println(no);
				case 5:
					System.exit(0);
				
			}
		}
	}
}
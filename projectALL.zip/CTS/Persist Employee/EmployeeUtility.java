import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;

public class EmployeeUtility implements Serializable{

	public boolean addEmployee(String fileName, ArrayList<Employee> employeeList) {
		boolean flag;
		int id=121;
    	String name="shubham";
    	float rating=5;
		try {

			FileOutputStream file = new FileOutputStream(fileName);
			ObjectOutputStream out = new ObjectOutputStream(file);
			//Employee emp=new Employee(id,name,rating);
			//employeeList.add(emp);
			out.writeObject(employeeList); 

			

			out.close();
			file.close();
			flag=true;
		}
		catch (IOException ex) {
			System.out.println("IOException is caught");
			flag=false;
		}
		return flag;
	}

	public Employee viewEmployeeById(String fileName, int employeeId) {
		Employee emp1=null;
		ArrayList<Employee> al=new ArrayList<>();
		try { 
			  
			
            FileInputStream file = new FileInputStream (fileName); 
                                         
            ObjectInputStream in = new ObjectInputStream  (file); 
                                     
           al= (ArrayList<Employee>) in.readObject(); 
           for(Employee emp:al)
           {
        	   if(emp.getEmployeeId()==employeeId)
        	   {
        		  return emp;
        		  // break;
        	   }
           }
           
           
        } 
  
        catch (IOException ex) { 
            System.out.println("IOException is caught"); 
        } 
  
        catch (ClassNotFoundException ex) { 
            System.out.println("ClassNotFoundException" + 
                                " is caught"); 
        } 
		return emp1;

	}
}
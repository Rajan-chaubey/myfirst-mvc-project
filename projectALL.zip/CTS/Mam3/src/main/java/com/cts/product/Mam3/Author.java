package com.cts.product.Mam3;

public class Author {
	private String first_name;
	private String last_name;
	private int age;
	private String phoneNo;
	private String address;
	public String getFirst_name() {
		return first_name;
	}
	public void setFirst_name(String first_name) {
		this.first_name = first_name;
	}
	public String getLast_name() {
		return last_name;
	}
	public void setLast_name(String last_name) {
		this.last_name = last_name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getPhoneNo() {
		return phoneNo;
	}
	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	@Override
	public String toString() {
		return "Author [first_name=" + first_name + ", last_name=" + last_name + ", age=" + age + ", phoneNo=" + phoneNo
				+ ", address=" + address + "]";
	}
	
	
}

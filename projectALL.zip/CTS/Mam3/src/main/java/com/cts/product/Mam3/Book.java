package com.cts.product.Mam3;

public class Book {
	private Author a;
	private String title;

	private int isbnNo;
	private int price;
	
	
	public Book() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	

	
	public Book(Author a) {
		super();
		this.a = a;
	}




	public Author getA() {
		return a;
	}
	public void setA(Author a) {
		this.a = a;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	
	public int getIsbnNo() {
		return isbnNo;
	}
	public void setIsbnNo(int isbnNo) {
		this.isbnNo = isbnNo;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	@Override
	public String toString() {
		return "Book [a=" + a + ", title=" + title + ", isbnNo=" + isbnNo + ", price=" + price
				+ "]";
	}
	
	
}

export interface User{
    username:string;
    password?:string;
    firstname:string;
    lastname:string;
    role?:string;
    accessToken?:string;
}
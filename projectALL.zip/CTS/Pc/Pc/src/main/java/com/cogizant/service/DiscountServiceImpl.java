package com.cogizant.service;

import org.springframework.stereotype.Service;

import com.cogizant.bean.ProductBean;

@Service
public class DiscountServiceImpl implements DiscountService {

	@Override
	public double calculateDiscount(ProductBean product) {
		// TODO Auto-generated method stub
		//Discounted Price = Product Price - ( Product Price *(Discount percentage /100))
		double discountPrice=0;
		if(product.getProductType().equals("Electronic")) {
		discountPrice=product.getProductPrice()-((product.getProductPrice())*25/100);
		}else  if(product.getProductType().equals("Apparels")) {
			discountPrice=product.getProductPrice()-((product.getProductPrice())*10/100);
		}else  if(product.getProductType().equals("Toys")) {
			discountPrice=product.getProductPrice()-((product.getProductPrice())*10/100);
		}else {
			discountPrice=0.0;
		}
		
		return discountPrice;
	}

}

package com.cogizant.service;

import com.cogizant.bean.ProductBean;

public interface DiscountService {
	double calculateDiscount(ProductBean product);
}

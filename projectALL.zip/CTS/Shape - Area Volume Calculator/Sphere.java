public class Sphere extends Shape implements Spatial
{
	public Sphere(double radius) {
		super();
		this.radius = radius;
	}

	private double radius;
	
    public double getRadius() {
		return radius;
	}

	public void setRadius(double radius) {
		this.radius = radius;
	}

	@Override
	public double area() {
		// TODO Auto-generated method stub
		double a=4*Math.PI*radius*radius;
		return a;
	}

	@Override
	public double volume() {
		// TODO Auto-generated method stub
		double v=(4*Math.PI*radius*radius*radius)/3;
		return v;
	}
	
	
    
}
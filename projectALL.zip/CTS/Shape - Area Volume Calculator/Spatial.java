public interface Spatial
{
    public double volume();
}
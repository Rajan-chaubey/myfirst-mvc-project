import java.util.Scanner;
public class Main{
   
    public static void main(String[] args){
        Scanner sc=new Scanner(System.in);
        
       int eId=sc.nextInt();
       String eName=sc.next();
       double eSal=sc.nextDouble();
       int eHourWorked=sc.nextInt();
       int eHourlyWages=sc.nextInt();
    
       PermanentEmployee ob1=new PermanentEmployee(eId,eName,eSal);

       TemporaryEmployee ob2=new TemporaryEmployee(eId, eName, eHourWorked, eHourlyWages);
    }
    
}

public class Loan {
	
	//Implement the below method 
	
	public double calculateLoanAmount(Employee employeeObj) {
		double lAmount;
		if (employeeObj instanceof PermanentEmployee) {
			//your code
			 lAmount= (15*employeeObj.getSalary())/100;
			}
		else
		{
			 lAmount= (10*employeeObj.getSalary())/100;
		}
		return lAmount;
	}

}

import java.util.InputMismatchException;
import java.util.Scanner;

public class ArrayException
{
	public String getPriceDetails()
	{
		String message="The array element is ";
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the number of elements in the array");
		int no=sc.nextInt();
		int arr[]=new int[no];
		int result;
		System.out.println("Enter the price details");
		try{
			for(int i=0; i<arr.length; i++)
			{
				arr[i]=sc.nextInt();
			}
			System.out.println("Enter the index of the array element you want to access");
			int element=sc.nextInt();
			if(element>=no)
			{
				throw new ArrayIndexOutOfBoundsException ();
			}
			else
			{
				 result=arr[element];
			}
			String ff=Integer.toString(result);
			ff=message+ff;
			return ff;
		}
		catch(InputMismatchException e)
		{
			return "Input was not in the correct format";
		}
		catch(ArrayIndexOutOfBoundsException e)
		{
			return "Array index is out of range";	
		}
		
	}
	
	
	
	
	
	
	
	public static void main(String[] args) {
		ArrayException obj=new ArrayException();
		String shubh=obj.getPriceDetails();
		System.out.println(shubh);
	}
}
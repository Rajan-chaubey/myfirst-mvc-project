package com.spring.app;

import org.springframework.context.support.ClassPathXmlApplicationContext;
public class Driver {
	public static  void main (String args[]) {
		ClassPathXmlApplicationContext  ctx = new ClassPathXmlApplicationContext("applicationContext.xml");
		MemberShip mm = (MemberShip) ctx.getBean("member");
		System.out.println(mm);
		
		
	}
	
}
